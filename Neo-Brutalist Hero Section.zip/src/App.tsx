import Hero from "./Hero";

export default function App() {
  return (
    <div className="w-full">
      <Hero />
    </div>
  );
}
