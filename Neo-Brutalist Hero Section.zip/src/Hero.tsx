import { useEffect, useRef } from "react";
import * as THREE from "three";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

// Draws a neo-brutalist "Ace of Spades" face onto a canvas → used as a texture map.
function makeCardFaceTexture(): HTMLCanvasElement {
  const W = 520;
  const H = 760;
  const c = document.createElement("canvas");
  c.width = W;
  c.height = H;
  const ctx = c.getContext("2d")!;

  // Base + thick brutalist double frame.
  ctx.fillStyle = "#FFDE59";
  ctx.fillRect(0, 0, W, H);
  ctx.strokeStyle = "#000";
  ctx.lineWidth = 34;
  ctx.strokeRect(17, 17, W - 34, H - 34);
  ctx.lineWidth = 8;
  ctx.strokeRect(54, 54, W - 108, H - 108);

  // Spade pip drawer with a hard offset shadow.
  const spade = (cx: number, cy: number, s: number, fill: string, outline = false) => {
    const path = () => {
      ctx.beginPath();
      ctx.moveTo(0, -1);
      ctx.bezierCurveTo(0.9, -0.1, 1.1, 0.7, 0.4, 1.0);
      ctx.bezierCurveTo(0.1, 1.12, 0.02, 0.9, 0, 0.72);
      ctx.bezierCurveTo(-0.02, 0.9, -0.1, 1.12, -0.4, 1.0);
      ctx.bezierCurveTo(-1.1, 0.7, -0.9, -0.1, 0, -1);
      ctx.closePath();
      ctx.moveTo(-0.28, 1.28);
      ctx.lineTo(0.28, 1.28);
      ctx.lineTo(0.08, 0.72);
      ctx.lineTo(-0.08, 0.72);
      ctx.closePath();
    };
    const draw = (ox: number, oy: number, color: string, stroke = false) => {
      ctx.save();
      ctx.translate(cx + ox, cy + oy);
      ctx.scale(s, s);
      path();
      ctx.fillStyle = color;
      ctx.fill();
      if (stroke) {
        ctx.lineWidth = 8 / s;
        ctx.strokeStyle = "#000";
        ctx.stroke();
      }
      ctx.restore();
    };
    draw(10, 12, "#000"); // offset shadow
    draw(0, 0, fill, outline);
  };

  // Center hero pip.
  spade(W / 2, H / 2, 150, "#FF90E8", true);

  // Corner index marks (top-left + bottom-right rotated).
  const corner = (x: number, y: number, flip: boolean) => {
    ctx.save();
    ctx.translate(x, y);
    if (flip) ctx.rotate(Math.PI);
    ctx.fillStyle = "#000";
    ctx.font = "900 92px 'Archivo Black', sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "alphabetic";
    ctx.fillText("A", 0, 0);
    spade(0, 52, 30, "#000");
    ctx.restore();
  };
  corner(104, 150, false);
  corner(W - 104, H - 150, true);

  return c;
}

// Rounded-rectangle shape used to extrude the playing-card body.
function roundedCardShape(w: number, h: number, r: number) {
  const shape = new THREE.Shape();
  const x = -w / 2;
  const y = -h / 2;
  shape.moveTo(x + r, y);
  shape.lineTo(x + w - r, y);
  shape.quadraticCurveTo(x + w, y, x + w, y + r);
  shape.lineTo(x + w, y + h - r);
  shape.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  shape.lineTo(x + r, y + h);
  shape.quadraticCurveTo(x, y + h, x, y + h - r);
  shape.lineTo(x, y + r);
  shape.quadraticCurveTo(x, y, x + r, y);
  return shape;
}

export default function Hero() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const textRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current!;
    const section = sectionRef.current!;

    const renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      alpha: true, // transparent canvas so the grid shows through
    });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(window.innerWidth, window.innerHeight);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(
      45,
      window.innerWidth / window.innerHeight,
      0.1,
      100,
    );
    camera.position.set(0, 0, 8);

    // --- Card mesh: extruded rounded rectangle with a metallic/foil finish ---
    const shape = roundedCardShape(2.6, 3.8, 0.28);
    const geometry = new THREE.ExtrudeGeometry(shape, {
      depth: 0.1,
      bevelEnabled: true,
      bevelThickness: 0.05,
      bevelSize: 0.05,
      bevelSegments: 5,
      curveSegments: 32,
    });
    geometry.center();

    // Remap UVs so the drawn face texture fits flat across the card faces.
    geometry.computeBoundingBox();
    const bb = geometry.boundingBox!;
    const uv = geometry.attributes.uv as THREE.BufferAttribute;
    const pos = geometry.attributes.position as THREE.BufferAttribute;
    const sx = bb.max.x - bb.min.x;
    const sy = bb.max.y - bb.min.y;
    for (let i = 0; i < uv.count; i++) {
      uv.setXY(i, (pos.getX(i) - bb.min.x) / sx, (pos.getY(i) - bb.min.y) / sy);
    }
    uv.needsUpdate = true;

    const faceTexture = new THREE.CanvasTexture(makeCardFaceTexture());
    faceTexture.colorSpace = THREE.SRGBColorSpace;
    faceTexture.anisotropy = 8;

    // Foil face: metallic sheen that still lets the printed art read clearly.
    const foilMaterial = new THREE.MeshPhysicalMaterial({
      map: faceTexture,
      metalness: 0.55,
      roughness: 0.32,
      clearcoat: 1,
      clearcoatRoughness: 0.12,
      reflectivity: 1,
      iridescence: 0.65,
      iridescenceIOR: 1.5,
      envMapIntensity: 1.15,
    });
    // Solid black extruded edge — the brutalist border rendered in 3D.
    const edgeMaterial = new THREE.MeshStandardMaterial({
      color: 0x000000,
      metalness: 0.1,
      roughness: 0.7,
    });

    // Procedural environment so the metal actually reflects something.
    const pmrem = new THREE.PMREMGenerator(renderer);
    const envScene = new THREE.Scene();
    const gradTex = (() => {
      const c = document.createElement("canvas");
      c.width = 4;
      c.height = 256;
      const ctx = c.getContext("2d")!;
      const g = ctx.createLinearGradient(0, 0, 0, 256);
      g.addColorStop(0, "#ff90e8");
      g.addColorStop(0.5, "#ffffff");
      g.addColorStop(1, "#ffde59");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, 4, 256);
      const t = new THREE.CanvasTexture(c);
      t.mapping = THREE.EquirectangularReflectionMapping;
      return t;
    })();
    envScene.background = gradTex;
    const envRT = pmrem.fromScene(envScene);
    scene.environment = envRT.texture;

    // ExtrudeGeometry emits group 0 = front/back faces, group 1 = extruded sides.
    const card = new THREE.Mesh(geometry, [foilMaterial, edgeMaterial]);

    const cardGroup = new THREE.Group();
    cardGroup.add(card);
    // Start off to the right, slightly tilted.
    cardGroup.position.set(3.4, -0.2, 0);
    cardGroup.rotation.set(-0.15, -0.5, 0.08);
    scene.add(cardGroup);

    // --- Lights ---
    scene.add(new THREE.AmbientLight(0xffffff, 0.6));
    const key = new THREE.DirectionalLight(0xffffff, 2.2);
    key.position.set(4, 6, 6);
    scene.add(key);
    const pink = new THREE.PointLight(0xff90e8, 3, 30);
    pink.position.set(-5, 2, 4);
    scene.add(pink);
    const yellow = new THREE.PointLight(0xffde59, 3, 30);
    yellow.position.set(5, -3, 4);
    scene.add(yellow);

    let raf = 0;
    const start = performance.now();
    const animate = () => {
      const t = (performance.now() - start) / 1000;
      // Gentle idle float layered on top of the scroll-driven transform.
      card.position.y = Math.sin(t * 1.2) * 0.06;
      renderer.render(scene, camera);
      raf = requestAnimationFrame(animate);
    };
    animate();

    // --- Scrollytelling timeline ---
    const tl = gsap.timeline({
      scrollTrigger: {
        trigger: section,
        start: "top top",
        end: "+=300%", // 300vh scroll distance
        pin: true,
        scrub: 1.2,
      },
    });

    // Card: glide from the right to center + full 360° Y rotation.
    tl.to(
      cardGroup.position,
      { x: 0, y: 0, ease: "power2.inOut" },
      0,
    )
      .to(
        cardGroup.rotation,
        { y: -0.5 + Math.PI * 2, x: 0, z: 0, ease: "none" },
        0,
      )
      // Zoom in slightly toward the end.
      .to(camera.position, { z: 6, ease: "power2.in" }, 0.7);

    // Hero text fades out and slides up.
    tl.to(
      textRef.current,
      { autoAlpha: 0, y: -80, ease: "power2.in" },
      0,
    );

    const onResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener("resize", onResize);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", onResize);
      tl.scrollTrigger?.kill();
      tl.kill();
      geometry.dispose();
      foilMaterial.dispose();
      edgeMaterial.dispose();
      faceTexture.dispose();
      gradTex.dispose();
      envRT.dispose();
      pmrem.dispose();
      renderer.dispose();
    };
  }, []);

  return (
    <div
      ref={sectionRef}
      className="relative h-screen w-full overflow-hidden"
      style={{
        backgroundColor: "#fdfaf7",
        backgroundImage:
          "linear-gradient(#00000010 1px, transparent 1px), linear-gradient(90deg, #00000010 1px, transparent 1px)",
        backgroundSize: "44px 44px",
      }}
    >
      {/* Three.js canvas overlaid behind the UI */}
      <canvas
        ref={canvasRef}
        className="pointer-events-none absolute inset-0 h-full w-full"
      />

      {/* Hero UI */}
      <div
        ref={textRef}
        className="relative z-10 flex h-full flex-col items-center justify-center px-6 text-center"
      >
        {/* Retro badge */}
        <div
          className="font-mono-nb mb-8 inline-flex items-center gap-2 border-[3px] border-black bg-[#FF90E8] px-4 py-2 text-xs font-bold tracking-widest text-black uppercase"
          style={{ boxShadow: "4px 4px 0px #000" }}
        >
          <span className="inline-block h-2 w-2 bg-black" />
          Deck v2.0 — Now Shuffling
        </div>

        {/* Headline */}
        <h1 className="font-display max-w-4xl text-5xl leading-[0.95] text-black uppercase sm:text-7xl lg:text-8xl">
          Play your{" "}
          <span
            className="inline-block -rotate-2 border-[3px] border-black bg-[#FFDE59] px-3 py-1 text-black"
            style={{ boxShadow: "4px 4px 0px #000" }}
          >
            winning
          </span>{" "}
          hand
        </h1>

        <p className="font-mono-nb mt-8 max-w-xl text-base text-black/70">
          Scroll to deal. A brutally honest deck engine built for people who
          hate losing more than they love winning.
        </p>

        {/* Interactive button */}
        <button
          className="font-display mt-10 border-[3px] border-black bg-black px-8 py-4 text-lg text-white uppercase transition-transform duration-100 hover:-translate-x-[2px] hover:-translate-y-[2px] active:translate-x-[2px] active:translate-y-[2px]"
          style={{ boxShadow: "6px 6px 0px #FF90E8" }}
          onMouseEnter={(e) => {
            e.currentTarget.style.boxShadow = "8px 8px 0px #FF90E8";
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.boxShadow = "6px 6px 0px #FF90E8";
          }}
        >
          Draw a card →
        </button>

        {/* Scroll cue */}
        <div className="font-mono-nb absolute bottom-8 left-1/2 -translate-x-1/2 text-xs font-bold tracking-widest text-black/50 uppercase">
          ↓ Scroll to reveal
        </div>
      </div>
    </div>
  );
}
